## hcloud datacenter describe

Describe a Datacenter (deprecated)

### Synopsis

The 'hcloud datacenter ...' commands are deprecated and will be removed after 1 Oct. 2026.
After this date, requests to the datacenters API endpoints will return HTTP 410 Gone.

See https://docs.hetzner.cloud/changelog#2026-06-02-datacenters-deprecated for more details.


```
hcloud datacenter describe [options] <datacenter>
```

### Options

```
  -h, --help                 help for describe
  -o, --output stringArray   output options: json|yaml|format
```

### Options inherited from parent commands

```
      --config string              Config file path (default "~/.config/hcloud/cli.toml")
      --context string             Currently active context
      --debug                      Enable debug output
      --debug-file string          File to write debug output to
      --endpoint string            Hetzner Cloud API endpoint (default "https://api.hetzner.cloud/v1")
      --hetzner-endpoint string    Hetzner API endpoint (default "https://api.hetzner.com/v1")
      --http-timeout duration      Timeout for HTTP requests (default 0 = no timeout)
      --no-experimental-warnings   If true, experimental warnings are not shown
      --poll-interval duration     Interval at which to poll information, for example action progress (default 500ms)
      --quiet                      If true, only print error messages
```

### SEE ALSO

* [hcloud datacenter](hcloud_datacenter.md)	 - View Datacenters (deprecated)

