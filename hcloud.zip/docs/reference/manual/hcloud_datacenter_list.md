## hcloud datacenter list

List Datacenters (deprecated)

### Synopsis

The 'hcloud datacenter ...' commands are deprecated and will be removed after 1 Oct. 2026.
After this date, requests to the datacenters API endpoints will return HTTP 410 Gone.

See https://docs.hetzner.cloud/changelog#2026-06-02-datacenters-deprecated for more details.

Displays a list of Datacenters.

Output can be controlled with the -o flag. Use -o noheader to suppress the
table header. Displayed columns and their order can be set with
-o columns=description,id (see available columns below).

Columns:
 - description
 - id
 - location
 - name

```
hcloud datacenter list [options]
```

### Options

```
  -h, --help                 help for list
  -o, --output stringArray   output options: noheader|columns=...|json|yaml
  -l, --selector string      Selector to filter by labels
  -s, --sort strings         Determine the sorting of the result
```

### Options inherited from parent commands

```
      --config string              Config file path (default "~/.config/hcloud/cli.toml")
      --context string             Currently active context
      --debug                      Enable debug output
      --debug-file string          File to write debug output to
      --endpoint string            Hetzner Cloud API endpoint (default "https://api.hetzner.cloud/v1")
      --hetzner-endpoint string    Hetzner API endpoint (default "https://api.hetzner.com/v1")
      --http-timeout duration      Timeout for HTTP requests (default 0 = no timeout)
      --no-experimental-warnings   If true, experimental warnings are not shown
      --poll-interval duration     Interval at which to poll information, for example action progress (default 500ms)
      --quiet                      If true, only print error messages
```

### SEE ALSO

* [hcloud datacenter](hcloud_datacenter.md)	 - View Datacenters (deprecated)

