## hcloud zone rrset change-ttl

Changes the Time To Live (TTL) of a Zone RRSet

```
hcloud zone rrset change-ttl (--ttl <ttl> | --unset) <zone> <name> <type>
```

### Options

```
  -h, --help      help for change-ttl
      --ttl int   Time To Live (TTL) of the Zone RRSet (required)
      --unset     Unset the Time To Live of Zone RRSet (use the Zone default TTL instead)
```

### Options inherited from parent commands

```
      --config string              Config file path (default "~/.config/hcloud/cli.toml")
      --context string             Currently active context
      --debug                      Enable debug output
      --debug-file string          File to write debug output to
      --endpoint string            Hetzner Cloud API endpoint (default "https://api.hetzner.cloud/v1")
      --hetzner-endpoint string    Hetzner API endpoint (default "https://api.hetzner.com/v1")
      --http-timeout duration      Timeout for HTTP requests (default 0 = no timeout)
      --no-experimental-warnings   If true, experimental warnings are not shown
      --poll-interval duration     Interval at which to poll information, for example action progress (default 500ms)
      --quiet                      If true, only print error messages
```

### SEE ALSO

* [hcloud zone rrset](hcloud_zone_rrset.md)	 - Manage Zone RRSets (records)

